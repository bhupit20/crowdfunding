export const separateNumber = (number) => {
    return Number(number).toLocaleString();
  };